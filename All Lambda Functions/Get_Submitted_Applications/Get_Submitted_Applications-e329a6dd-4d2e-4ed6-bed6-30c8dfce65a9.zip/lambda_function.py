import json
import boto3
from datetime import datetime,date

def lambda_handler(event,context):
    dynamodb = boto3.resource('dynamodb')
    client = boto3.client('dynamodb')
    table = dynamodb.Table('Submitted_Applications')
    
    if 'id' in event['params']['querystring'] and '_' in event['params']['querystring']['id']:
        
        id = event['params']['querystring']['id']
        response = table.get_item(
            Key={
                "applicationid_email" :event['params']['querystring']['id']
                
            }
            )
        
        return {
            "status":200,
            "body":response
        }
        
    elif 'id' in event['params']['querystring'] and '_' not in event['params']['querystring']['id']:
        
        submittedapplications = table.scan()
        response = {"Items":[]}
        id = event['params']['querystring']['id']
        for key in submittedapplications['Items']:
            if(key['applicationid_email'].startswith(id)):
                response["Items"].append(key)
            return{
                "status":200,
                "body":response
            }
         
    else:
        return {
            'status' : 400,
            'body':'Forbidden'
        }