import json
import boto3
import pprint
from datetime import datetime, date

def lambda_handler(event,context):
    dynamodb = boto3.resource("dynamodb")
    client = boto3.client("dynamodb")
    table = dynamodb.Table("Submitted_Applications")
    id = event['applicationid']+"_"+event['email']
    
    singleapplicationdata = table.get_item(
        Key={
            'applicationid_email' : id}
            )
    if 'applicationid' in event and 'email' in event:
        response = table.update_item(
            Key={
                'applicationid_email' : id
                
            },
            UpdateExpression = "SET submission= :g",
            ExpressionAttributeValues = {':g' : [event['submission']]},
            ReturnValues = "UPDATED_NEW"
        )
        return {
            # this will also contain the XMLHTTPResponse status
            "status": "200",
            "body": response,
            }
    else:
        return{
            "status":"403",
            "body":"Forbidden"
        }
            
# def lambda_handler(event, context):
#     dynamodb = boto3.resource("dynamodb")
#     client = boto3.client("dynamodb")
#     table = dynamodb.Table("Applications")
#     requestJSON = event
    
#     if "applicationid" in event:
#         singleapplicationdata = table.get_item(
#             Key={
#                 'ApplicationID' : event['applicationid']}
#         )
#         print(singleapplicationdata['Item']['submittedApplications'])
#         if 'submittedApplications' in singleapplicationdata['Item'] and 'email' in event and event['email'] in singleapplicationdata['Item']['submittedApplications']:
#             singleapplicationdata['Item']['submittedApplications'][event['email']] = event['submission']
#             response=table.update_item(
#             Key={
#                 'ApplicationID' : event["applicationid"]
                            
#                 },
#             UpdateExpression="set submittedApplications =list_append(submittedApplications, :g)",
#             ExpressionAttributeValues={":g": [singleapplicationdata]},
#             ReturnValues="UPDATED_NEW",
#             )
#             return {
#                         # this will also contain the XMLHTTPResponse status
#             "status": "200",
#             "body": response,
#         }
#         else:
#             print("error")
    # if 'submission' in event and 'applicationid' in event:
    #     try:
    #         response=table.update_item(
    #       Key={
    #                 'ApplicationID':event['applicationid'] ,
    #       },
    #       UpdateExpression="set submittedApplications =list_append(submittedApplications, :g)",
    #       ExpressionAttributeValues={':g': [event]},

    #       ReturnValues="UPDATED_NEW"
    #     )
    #         return {
    #             # this will also contain the XMLHTTPResponse status
    #             'status':'200',
    #             'body':response
    #         }
    #     except :
    #         return{
    #         'status':'400',
    #         'body':{
    #             'message':'user email does not exit !'
    #         }
    #     }

    # else :
    #     return{
    #         'status':'400',
    #         'body':{
    #             'message':'something went wrong !'
    #         }
    #     }
