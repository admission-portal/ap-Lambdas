const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };
        await dynamo
          .delete({
            TableName: "Users",
            Key: {
              "id": event.id
            }
          })
          .promise();
        body = `Deleted item ${event.id}`;
   
     return {
    statusCode,
    body,
    headers
  };
    
};